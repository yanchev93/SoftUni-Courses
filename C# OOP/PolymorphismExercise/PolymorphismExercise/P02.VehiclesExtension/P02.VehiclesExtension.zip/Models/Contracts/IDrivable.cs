﻿namespace P02.VehiclesExtension.Models.Contracts
{
    public interface IDrivable
    {
        public string Drive(double distance);

    }
}
