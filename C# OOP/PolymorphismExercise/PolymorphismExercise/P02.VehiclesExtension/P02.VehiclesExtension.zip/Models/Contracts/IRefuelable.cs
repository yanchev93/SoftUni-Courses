﻿namespace P02.VehiclesExtension.Models.Contracts
{
    public interface IRefuelable
    {
        public void Refuel(double liters);
    }
}
