﻿namespace P03.ShopingSpree
{
    public class ConstantExceptions
    {
        public static string NameException = "Name cannot be empty";
        public static string MoneyException = "Money cannot be negative";
        public static string InsufficientMoneyExceptionMessage =
            "{0} can't afford {1}"; 
    }
}
