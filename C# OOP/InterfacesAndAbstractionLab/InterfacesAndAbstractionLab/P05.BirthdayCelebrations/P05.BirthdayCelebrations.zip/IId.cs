﻿namespace P05.BirthdayCelebrations

{
    public interface IId
    {
        public string Id { get; }
    }
}
