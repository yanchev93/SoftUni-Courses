﻿namespace P05.BirthdayCelebrations
{
    public interface IBirthday
    {
        public string Birthday { get; }
    }
}
