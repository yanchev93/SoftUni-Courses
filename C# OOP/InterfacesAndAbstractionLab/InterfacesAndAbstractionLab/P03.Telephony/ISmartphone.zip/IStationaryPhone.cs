﻿namespace P03.Telephony
{
    public interface IStationaryPhone
    {
        public string Dialing(string number);
    }
}
