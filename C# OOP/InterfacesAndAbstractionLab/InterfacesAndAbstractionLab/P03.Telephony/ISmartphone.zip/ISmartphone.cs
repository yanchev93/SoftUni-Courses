﻿namespace P03.Telephony
{
    public interface ISmartphone
    {
        public string Calling(string number);
        public string Browse(string site);
    }
}
