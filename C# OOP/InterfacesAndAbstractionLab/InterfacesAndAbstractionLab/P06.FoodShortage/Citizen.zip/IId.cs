﻿namespace P06.FoodShortage
{
    interface IId
    {
        public string Id { get; }
    }
}
