﻿namespace P06.FoodShortage
{
    public interface IBirthday
    {
        public string Birthday { get; }
    }
}
