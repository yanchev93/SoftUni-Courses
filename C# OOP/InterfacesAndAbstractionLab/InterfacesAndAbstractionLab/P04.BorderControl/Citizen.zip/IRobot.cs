﻿namespace P04.BorderControl
{
    public interface IRobot
    {
        public string Model { get; }

        public string Id { get; }
    }
}
