﻿namespace P01.Vehicles.Common
{
    public static class ExceptionMessages
    {
        public static string NotEnoughFuel = "{0} needs refueling";
    }
}
