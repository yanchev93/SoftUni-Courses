﻿namespace P01.Vehicles.Models.Contracts
{
    public interface IDrivable
    {
        public string Drive(double distance);

    }
}
