﻿namespace P01.Vehicles.Models.Contracts
{
    public interface IRefuelable
    {
        public void Refuel(double liters);
    }
}
