﻿using System;

namespace P02._MultipleInheritance
{
    public class Puppy : Dog
    {
        public void Weep()
        {
            Console.WriteLine("weeping...");
        }
    }
}
