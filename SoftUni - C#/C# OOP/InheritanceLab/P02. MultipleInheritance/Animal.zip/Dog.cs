﻿using System;

namespace P02._MultipleInheritance
{
    public class Dog : Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }
}
