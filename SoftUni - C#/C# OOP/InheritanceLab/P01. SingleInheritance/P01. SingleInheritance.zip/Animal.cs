﻿using System;

namespace P01._SingleInheritance
{
    public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
