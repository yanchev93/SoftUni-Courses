﻿namespace P05.FootballTeamGenerator
{
    using System;

    using P05.FootballTeamGenerator.Core;

    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
