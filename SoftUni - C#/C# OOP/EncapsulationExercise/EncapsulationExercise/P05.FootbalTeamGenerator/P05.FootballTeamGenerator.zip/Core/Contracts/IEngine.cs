﻿namespace P05.FootballTeamGenerator
{
    public interface IEngine
    {
        public void Run();
    }
}
