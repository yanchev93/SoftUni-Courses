﻿namespace P04.BorderControl
{
    public interface IModel
    {
        public string Id { get; }
    }
}
