﻿namespace P04.BorderControl
{
    public interface ICitizen : IModel
    {
        public int Age { get; }
    }
}
