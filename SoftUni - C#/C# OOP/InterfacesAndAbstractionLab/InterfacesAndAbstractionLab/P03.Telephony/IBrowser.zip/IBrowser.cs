﻿public interface IBrowser
{
    string Browse(string url);
}