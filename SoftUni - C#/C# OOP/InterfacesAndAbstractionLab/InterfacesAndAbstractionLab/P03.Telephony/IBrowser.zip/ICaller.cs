﻿public interface ICaller
{
    string Call(string number);
}